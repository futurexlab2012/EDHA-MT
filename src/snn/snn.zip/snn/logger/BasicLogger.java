package com.example.futurexlab.edhamt.snn.logger;


public class BasicLogger implements Logger {
    final static int ERROR = 0;
    final static int WARNING = 1;
    final static int INFO = 2;
    final static int DEBUG = 3;

    private int logLevel = DEBUG;

    public void setLogLevel(int logLevel) {
        this.logLevel = logLevel;
    }

    @Override
    public void debug(String msg) {
        if (logLevel >= DEBUG) {
            System.out.println(msg);
        }
    }

    @Override
    public void info(String msg) {
        if (logLevel >= INFO) {
            System.out.println(msg);
        }
    }

    @Override
    public void warning(String msg) {
        if (logLevel >= WARNING) {
            System.out.println(msg);
        }
    }

    @Override
    public void error(Exception exception, String... msg) {
        for (String s : msg) {
            System.out.println(s);
        }
        exception.printStackTrace();
        System.exit(1);  //If an exception occurs, exit directly
    }
}
