package com.example.futurexlab.edhamt.snn.logger;

/**
 * Log interface
 */

public interface Logger {
    /**
     * Debugging Output
     *
     * @param msg messages
     */
    void debug(String msg);

    /**
     * Normal Output
     *
     * @param msg messages
     */
    void info(String msg);

    /**
     * Warning Output
     *
     * @param msg messages
     */
    void warning(String msg);

    /**
     * Error Output
     *
     * @param exception error
     * @param msg       extra messages
     */
    void error(Exception exception, String... msg);
}
