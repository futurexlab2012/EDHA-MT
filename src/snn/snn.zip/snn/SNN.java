package com.example.futurexlab.edhamt.snn;

import com.example.futurexlab.edhamt.snn.logger.Logger;
import com.example.futurexlab.edhamt.snn.monitor.recorder.SpikeRecorder;
import com.example.futurexlab.edhamt.snn.neuron.Neuron;
import com.example.futurexlab.edhamt.snn.queue.ReentrantQueue;

import com.example.futurexlab.edhamt.threads.NNLib;


/**
 * The actual framework for computing
 */
public class SNN {

    private final ReentrantQueue<Neuron> queue;
    private final Logger logger;
    private double currentTime;
    public static NNLib snnlib = new NNLib();
    public static SpikeRecorder spikeRecorder = snnlib.GenSpikeRecorder();

    public SNN(ReentrantQueue<Neuron> queue, Logger logger) {
        this.queue = queue;
        this.logger = logger;
        this.currentTime = 0;
    }

    public double run(double duration) {
        Neuron lastNeuron = null;
        double endTime = currentTime + duration;

        while (currentTime < endTime) {


            Neuron neuron = queue.pop();

            if (neuron == null) {
                return currentTime;
            }


            currentTime = neuron.sortKey();    //current time is the neuron spike time

            //一个个神经元计算更新
            neuron.calculate(queue,logger);       //compute the current neuron


        }

        return currentTime;  //return the nearest spike time to facilitate the next calculation
    }

}
