package com.example.futurexlab.edhamt.snn.easySNN;

import com.example.futurexlab.edhamt.snn.inputUtils.EmptySynapse;
import com.example.futurexlab.edhamt.snn.inputUtils.InputSoma;
import com.example.futurexlab.edhamt.snn.inputUtils.OriginSoma;
import com.example.futurexlab.edhamt.snn.inputUtils.SpikeReader;
import com.example.futurexlab.edhamt.snn.neuron.Neuron;
import com.example.futurexlab.edhamt.snn.queue.ReentrantQueue;

/**
 * A simpler tool for creating input neuron groups,
 * It is the integration of InputSoma and OriginSoma.
 * Users do not need to care about internal connections.
 */

public class EasyInputGroup {
    /**
     * More advanced mode, more configuration support
     *
     * @param n                    Number of input neurons
     * @param spikeReader          Source of spikes
     * @param queue                Neurons manage queues
     * @param bufferSize           BufferSize for each input neuron
     * @param originSomaBufferSize BufferSize for originSoma
     * @return  All the input neurons for subsequent connections
     */
    public static Neuron[] NewInputGroupAdvance(int n, int bufferSize, int originSomaBufferSize, SpikeReader spikeReader, ReentrantQueue<Neuron> queue) {
        InputSoma[] inputSomas = new InputSoma[n];
        Neuron[] inputNeurons = new Neuron[n];
        for (int i = 0; i < inputSomas.length; i++) {
            InputSoma inputSoma = new InputSoma(bufferSize);
            inputSomas[i] = inputSoma;
            inputNeurons[i] = new Neuron(inputSoma);
        }
        OriginSoma originSoma = new OriginSoma(inputSomas, spikeReader, originSomaBufferSize);
        Neuron originNeuron = new Neuron(originSoma, 1e-5);
        queue.add(originNeuron);

        //neuron connection
        originNeuron.connect(originNeuron, new EmptySynapse());//input neuron self-connection
        for (Neuron inputNeuron : inputNeurons) {
            originNeuron.connect(inputNeuron, new EmptySynapse());   //Connection between originating neuron and input neuron
            inputNeuron.connect(inputNeuron, new EmptySynapse());    //input neuron self-connection
        }
        return inputNeurons;
    }

    public static Neuron[] NewInputGroup(int n, SpikeReader spikeReader, ReentrantQueue<Neuron> queue) {
        return NewInputGroupAdvance(n, 8, 32, spikeReader, queue);
    }

  
}
