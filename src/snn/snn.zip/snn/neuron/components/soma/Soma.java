package com.example.futurexlab.edhamt.snn.neuron.components.soma;


public interface Soma {
    /**
     * This function is called to indicate that the preceding neuron fired
     *
     * @param deltaGe     change of ge
     * @param currentTime current time
     * @return spike time, if <0 indicates there is no spike
     */
    double update(double deltaGe, double currentTime);
}
