package com.example.futurexlab.edhamt.snn.neuron.components.soma;

/**
 * The standard LIF model implementation.
 * If the need to extend the functionality, recommended to use the proxy mode implementation, inheritance can cause many problems.
 */

public class Lif implements Soma {

    private final float threshold;
    private final float vReset;
    private final float tv;
    private final float tg;
    private final float refractoryTime;

    private float voltage;
    private float ge = 0; //current ge
    private double exceptedSpikeTime = -1;  //predicted spike time
    private double lastSpikeTime = -1;
    private double lastUpdateTime = 0;      //last membrane potential update time

    /**
     * @param threshold      threshold
     * @param vReset         v reset
     * @param tv             leakage current time constant
     * @param tg             conductance time constant
     * @param refractoryTime refractory time
     */
    public Lif(float threshold, float vReset, float tv, float tg, float refractoryTime) {
        this.threshold = threshold;
        this.vReset = vReset;
        this.tv = tv;
        this.tg = tg;
        this.refractoryTime = refractoryTime;
        this.voltage = vReset;
    }

    //provides an interface for solving equations.
    interface Function {
        double f(double x);
    }

    private double dichotomy(double left, double right, int order, Function f) {
        if (Math.abs(f.f(left))<0.01){
            return left;
        }
        if (left > right || f.f(left) * f.f(right) > 0) {
            System.out.println(left + " " + right + " " + f.f(left) + " " + f.f(right));
            new Exception("dichotomy error").printStackTrace();
            System.exit(1);
        }
        for (int i = 0; i < order; i++) {
            double m = (left + right) / 2;
            if (f.f(m) * f.f(left) < 0) {   //[left,m]
                right = m;
            } else {
                left = m;
            }
        }
        return (left + right) / 2;
    }

    @Override
    public double update(double deltaGe, double currentTime) {
//        if (deltaGe>-100000]0000) return -1;
        double lastVoltage=-85;
        if (exceptedSpikeTime > 0 && currentTime > exceptedSpikeTime) {   //already had a spike, so reset the membrane potential
            voltage = vReset;
            ge = 0;  //conductance should be cleared after the spike
            lastUpdateTime = exceptedSpikeTime;
            lastSpikeTime = exceptedSpikeTime;  //Record the time of the last spike for the refractory period
            exceptedSpikeTime = -1;
        } else { // If a spike is generated, the conductivity and membrane potential equal to the lowest value and do not change until the new spike arrives
            //Update membrane potential changes due to leakage current after the last spike
            lastVoltage = this.voltage;
            double ge0 = this.ge;
            float w0 = this.voltage - vReset;
            double ge = ge0 * Math.exp(-(currentTime - this.lastUpdateTime) / this.tg);
            double c2 = (w0 - ge0 * this.tv * this.tg / (this.tg - this.tv)) / Math.exp(-this.lastUpdateTime / this.tv);
            double w = c2 * Math.exp(-currentTime / this.tv) + ge * this.tv * this.tg / (this.tg - this.tv);
            this.voltage = (float) w + vReset;
            this.ge = (float) ge;
        }
        //If the time is within the refractory period, the spike is ignored
        if (currentTime - lastSpikeTime < refractoryTime) {
            return -1;
        }
        //Predict the maximum membrane potential
        this.ge += deltaGe;
        this.lastUpdateTime = currentTime;
        if (this.ge < 0){
            return -1;
        }
        double ge0 = this.ge;
        double w0 = this.voltage - vReset;
        double c1 = -Math.log(ge0) - currentTime / this.tg;
        double c2 = (w0 - ge0 * this.tv * this.tg / (this.tg - this.tv)) / Math.exp(-this.lastUpdateTime / this.tv);
        double c3 = Math.exp(-c1) * (this.tv * this.tg) / (this.tg - this.tv);
        double tPeak = Math.log(-c3 * this.tv / c2 / this.tg) * this.tg * this.tv / (this.tv - this.tg);
        if (tPeak<currentTime){
            return -1;
        }
        double vPeak = c2 * Math.exp(-tPeak / this.tv) + c3 * Math.exp(-tPeak / this.tg) + vReset;

        System.out.println(currentTime+" "+tPeak+" "+deltaGe +"   c1="+c1 + " c2="+c2+ "  c3="+c3);
        //If a spike can be generated, solve the equation to get spike time
        if (vPeak > threshold) {
            Function f = (double x) -> c2 * Math.exp(-x / this.tv) + c3 * Math.exp(-x / this.tg) + vReset - threshold;
            // Substitution method. Retention
//            Function sf = (double x) -> c2 * x + c3 * Math.exp(this.tv / this.tg) * x + vReset - threshold;
//            Function trnas = (double t) -> Math.exp(-t / this.tv);
//            System.out.println("last voltage=" + lastVoltage+" current voltage=" + this.voltage);
            double spikeTime = this.dichotomy(currentTime, tPeak, 10, f);  //Solve the equation and estimate the spike time
//            spikeTime = -this.tv * Math.log(spikeTime);
            this.exceptedSpikeTime = spikeTime;  //update spike time
            return spikeTime;
        } else {
            return -1;  // The conditions for generating pulses are not met.
        }
    }
}
