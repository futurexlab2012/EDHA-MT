package com.example.futurexlab.edhamt.snn.neuron.components.soma;

/**
 * The standard LIF model implementation.
 * If the need to extend the functionality, recommended to use the proxy mode implementation, inheritance can cause many problems.
 */

public class LifFix implements Soma {

    private final float threshold;
    private final float vReset;
    private final float tv;
    private final float tg;
    private final float refractoryTime;

    private float voltage;
    private final float threDelta;
    private final float threTime;
    private float ge = 0; //current ge
    private double exceptedSpikeTime = -1;  //predicted spike time
    private double lastSpikeTime = -100;
    private double lastUpdateTime = 0;      //last membrane potential update time
    private double extraThreshold = 0;

    private double lastpeakV = 0;
    public int nSpike = 0;

    public double getExtraThreshold() {
        return extraThreshold;
    }

    public void setExtraThreshold(double extraThreshold) {
        this.extraThreshold = extraThreshold;
    }

    /**
     * @param threshold      threshold
     * @param vReset         v reset
     * @param tv             leakage current time constant
     * @param tg             conductance time constant
     * @param refractoryTime refractory time
     */
    public LifFix(float threshold, float vReset, float tv, float tg, float refractoryTime, float threDelta, float threTime) {
        this.threshold = threshold;
        this.vReset = vReset;
        this.tv = tv;
        this.tg = tg;
        this.refractoryTime = refractoryTime;
        this.voltage = vReset;
        this.threDelta = threDelta;
        this.threTime = threTime;
        this.extraThreshold = 0;
    }

    public LifFix(float threshold, float vReset, float tv, float tg, float refractoryTime) {
        this.threshold = threshold;
        this.vReset = vReset;
        this.tv = tv;
        this.tg = tg;
        this.refractoryTime = refractoryTime;
        this.voltage = vReset;
        this.threDelta = 0;
        this.threTime = 1e7f;
        this.extraThreshold = 0;
    }

    //provides an interface for solving equations.
    interface Function {
        double f(double x);
    }

    private double dichotomy(double left, double right, int order, Function f) {
        if (f.f(left) > 0) {
//            System.out.println(f.f(left));
            return left + 1e-8;
        }
        if (left > right || f.f(left) * f.f(right) > 0) {
            System.out.println(left + " " + right + " " + f.f(left) + " " + f.f(right));
            new Exception("dichotomy error").printStackTrace();
            System.exit(1);
        }
        for (int i = 0; i < order; i++) {
            double m = (left + right) / 2;
            if (f.f(m) * f.f(left) < 0) {   //[left,m]
                right = m;
            } else {
                left = m;
            }
        }
        return (left + right) / 2;
    }

    @Override
    public double update(double deltaGe, double currentTime) {
//        System.out.println("receive "+deltaGe);
//        if (deltaGe>-100000]0000) return -1;
        if (exceptedSpikeTime > 0 && currentTime > exceptedSpikeTime) {   //already had a spike, so reset the membrane potential
            extraThreshold = this.threDelta + extraThreshold * Math.exp(-(exceptedSpikeTime - lastSpikeTime) / threTime);
            voltage = vReset;
            ge = 0;  //conductance should be cleared after the spike
            lastUpdateTime = exceptedSpikeTime;
            lastSpikeTime = exceptedSpikeTime;  //Record the time of the last spike for the refractory period
            exceptedSpikeTime = -1;
            nSpike += 1;
        } else { // If a spike is generated, the conductivity and membrane potential equal to the lowest value and do not change until the new spike arrives
            //Update membrane potential changes due to leakage current after the last spike
            double deltaTime = currentTime - this.lastUpdateTime;
            double ge0 = this.ge;
            float w0 = this.voltage - vReset;
            double ge = ge0 * Math.exp(-(deltaTime) / this.tg);
            double c2 = (w0 - ge0 * this.tv * this.tg / (this.tg - this.tv));
            double w = c2 * Math.exp(-deltaTime / this.tv) + ge * this.tv * this.tg / (this.tg - this.tv);
            this.voltage = (float) w + vReset;
            this.ge = (float) ge;
//            System.out.println(currentTime + " c2=" + c2 + " currentVoltage=" + this.voltage);

        }
        this.lastUpdateTime = currentTime;

        //If the time is within the refractory period, the spike is ignored
        if (currentTime - lastSpikeTime < refractoryTime) {
//            System.out.println("in refract");
            exceptedSpikeTime = -1;
            return -1;
        }
        this.ge += deltaGe;

        if (this.ge < 0) {
            exceptedSpikeTime = -1;
            return -1;
        }
        double newThreshold = threshold + extraThreshold * Math.exp(-(currentTime - lastSpikeTime) / threTime);
        if (this.voltage > newThreshold) {
            this.exceptedSpikeTime = currentTime;
            return currentTime;
        }

        //Predict the maximum membrane potential
        double ge0 = this.ge;
        double w0 = this.voltage - vReset;
        double c2 = (w0 - ge0 * this.tv * this.tg / (this.tg - this.tv));
        double c3 = ge0 * (this.tv * this.tg) / (this.tg - this.tv);
        if (c2 < 0) {
            exceptedSpikeTime = -1;
            return -1;   //C2 < 0 means it's monotonous
        }
        double tPeak = Math.log(-c3 * this.tv / c2 / this.tg) * this.tg * this.tv / (this.tv - this.tg);
        if (tPeak < 0) {
            exceptedSpikeTime = -1;
            return -1;  // It means that the membrane potential is decreasing at the current position, so it goes straight back
        }

        double vPeak = c2 * Math.exp(-tPeak / this.tv) + c3 * Math.exp(-tPeak / this.tg) + vReset;

//        if (currentTime - lastSpikeTime < refractoryTime)
//            System.out.println(currentTime + " " + tPeak + " " + deltaGe + " c2=" + c2 + "  c3=" + c3 + " lastPeak=" + lastpeakV + " expectSpikeTime=" + this.exceptedSpikeTime);
        lastpeakV = lastSpikeTime;
        //If a spike can be generated, solve the equation to get spike time
        if (vPeak > newThreshold) {
            Function f = (double x) -> c2 * Math.exp(-x / this.tv) + c3 * Math.exp(-x / this.tg) + vReset - newThreshold;
            double spikeTime = this.dichotomy(0, tPeak, 10, f) + currentTime;  //Solve the equation and estimate the spike time
            this.exceptedSpikeTime = spikeTime;  //update spike time
//            System.out.println("spike at " + spikeTime);
            return spikeTime;
        } else {
            exceptedSpikeTime = -1;
            return -1;  // The conditions for generating pulses are not met.
        }
    }
}
