package com.example.futurexlab.edhamt.snn.neuron.components.synapse;

/**
 * The LTD part is a constant STDP, which is used to realize supervised learning and fast unsupervised convergence
 */

public class LTDConstantSTDP implements Synapse {

    static public class SharedVariate {
        public double value;

        public SharedVariate(double value) {
            this.value = value;
        }
    }

    private final double ltdConstant;
    private final double ltpAmplitude;
    private int LTPLeakyTimeConstant;
    private final double ltpConstant;
    private double weight;
    private double learningRate;
    private double lastPreSpikeTime;
    private double lastPostSpikeTime;
    private boolean plastic = true;

    private SharedVariate geAmplifyFactor;

    public void setPlastic(boolean plastic) {
        this.plastic = plastic;
    }

    public LTDConstantSTDP(double initWeight, double LTDConstant, double LTPAmplitude, int LTPLeakyTimeConstant, double LTPConstant, double learningRate, SharedVariate geAmplifyFactor) {
        ltdConstant = LTDConstant;
        ltpAmplitude = LTPAmplitude;
        this.LTPLeakyTimeConstant = LTPLeakyTimeConstant;
        ltpConstant = LTPConstant;
        weight = initWeight;
        this.geAmplifyFactor = geAmplifyFactor;
        this.learningRate = learningRate;
        lastPreSpikeTime = -1000;
        lastPostSpikeTime = -1000;
    }

    private double weightDelta(double isi) {
        if (isi < 0) {
//            return ltdConstant * learningRate;
            return 0;
        }
        return learningRate * (Math.exp(-isi / LTPLeakyTimeConstant) * ltpAmplitude + ltpConstant);
    }

    @Override
    public double preSpike(double currentTime) {
        if (plastic) {

            lastPreSpikeTime = currentTime;
            weight += weightDelta(lastPostSpikeTime - lastPreSpikeTime);
            if (weight < -1) {
                weight = -1;
            } else if (weight > 2) {
                weight = 2;
            }

            //System.out.println(weight);
        }
        return weight * geAmplifyFactor.value;
    }

    @Override
    public void postSpike(double currentTime) {
        if (plastic) {
            lastPostSpikeTime = currentTime;
            weight += weightDelta(lastPostSpikeTime - lastPreSpikeTime);
            if (weight < -1) {
                weight = -1;
            } else if (weight > 2) {
                weight = 2;
            }
        }
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weightvaule) {
        this.weight = weightvaule;
    }

    public void setLearningRate(double learningRate) {
        this.learningRate = learningRate;
    }
}
