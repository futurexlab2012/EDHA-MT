package com.example.futurexlab.edhamt.snn.neuron.components.synapse;


public class ConstantSynapse implements Synapse {

    private double weight;
    private LTDConstantSTDP.SharedVariate geAmplifyFactor = null;

    public ConstantSynapse(double weight) {
        this.weight = weight;
    }

    public ConstantSynapse(double weight, LTDConstantSTDP.SharedVariate geAmplifyFactor) {
        this.weight = weight;
        this.geAmplifyFactor = geAmplifyFactor;
    }

    @Override
    public double preSpike(double currentTime) {
        return geAmplifyFactor == null ? weight : weight * geAmplifyFactor.value;
    }

    @Override
    public void postSpike(double currentTime) {

    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
