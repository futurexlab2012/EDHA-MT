package com.example.futurexlab.edhamt.snn.neuron.components.synapse;


public interface Synapse {
    /**
     * @param currentTime current time
     * @return return the current synapse weight, which will be passed to the cell body in Soma's "update" method
     */
    double preSpike(double currentTime);

    /**
     * @param currentTime current time
     */
    void postSpike(double currentTime);
}
