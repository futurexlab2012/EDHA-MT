package com.example.futurexlab.edhamt.snn.neuron;

import com.example.futurexlab.edhamt.snn.logger.Logger;
import com.example.futurexlab.edhamt.snn.neuron.components.soma.Soma;
import com.example.futurexlab.edhamt.snn.neuron.components.synapse.Synapse;
import com.example.futurexlab.edhamt.snn.queue.ReentrantQueue;
import com.example.futurexlab.edhamt.snn.queue.Sorter;

import java.util.ArrayList;


public class Neuron implements Sorter {
    private double expectSpikeTime;  //predicted spike time
    private final Soma soma;       //neuron soma
    private final ArrayList<Neuron> postNeurons = new ArrayList<>();  //post-synaptic neuron
    private final ArrayList<Synapse> postSynapses = new ArrayList<>(); //post synapse
    private final ArrayList<Synapse> preSynapses = new ArrayList<>();  //pre synapse
    private final String alias;
    public int nSpike;

    public String getAlias() {
        return alias;
    }


    public Neuron(Soma soma) {
        this.soma = soma;
        this.alias = "";
    }

    public Neuron(Soma soma, double expectSpikeTime) {
        this.expectSpikeTime = expectSpikeTime;
        this.soma = soma;
        this.alias = "";
    }

    public Neuron(Soma soma, String alias) {
        this.soma = soma;
        this.alias = alias;
    }

    private double update(double weight, double currentTime) {
        expectSpikeTime = soma.update(weight, currentTime);
        return expectSpikeTime;
    }



    // Key Method
    public void neuroncal(ReentrantQueue<Neuron> queue,double currentTime){
            for (int i = 0; i < postNeurons.size(); i++) {


                Synapse synapse = postSynapses.get(i);
                Neuron neuron = postNeurons.get(i);
                double delta = synapse.preSpike(currentTime);
                neuron.update(delta, currentTime);

                queue.add(neuron);


        }
    }


    public void calculate(ReentrantQueue<Neuron> queue,Logger logger)  {

        double currentTime;
        if (expectSpikeTime > 0) {

            nSpike++;
            currentTime = expectSpikeTime;

            neuroncal(queue,currentTime);


            for (Synapse synapse : preSynapses) {
                synapse.postSpike(currentTime);   //spike from post-synaptic neuron

            }

        } else {
            System.out.println(this.soma);
            logger.error(new Exception("spike error at neuron"), " " + expectSpikeTime);// time < 0 indicates that abnormal data is mixed in the spike queue
        }

    }

    public void connect(Neuron next, Synapse synapse) {  //connection
        // can implement self-connection, here is normal connection
        postNeurons.add(next);
        postSynapses.add(synapse);
        next.preSynapses.add(synapse);
    }

    @Override
    public double sortKey() {
        return expectSpikeTime;
    }

    public void setExpectSpikeTime(double expectSpikeTime) {
        this.expectSpikeTime = expectSpikeTime;
    }

    public Soma getSoma() {
        return soma;
    }
}
