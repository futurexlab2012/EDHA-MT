package com.example.futurexlab.edhamt.snn.monitor.recorder;

import com.example.futurexlab.edhamt.snn.neuron.Neuron;
import com.example.futurexlab.edhamt.snn.queue.ReentrantQueue;
import com.example.futurexlab.edhamt.snn.utils.RingBufferQueue;

//脉冲记录器
public class SpikeRecorder implements ReentrantQueue<Neuron> {

    private final ReentrantQueue<Neuron> queue;
    private RingBufferQueue<Neuron> neuronQueue = new RingBufferQueue<>(64);
    private RingBufferQueue<Double> timeQueue = new RingBufferQueue<>(64);

    public SpikeRecorder(ReentrantQueue<Neuron> queue) {
        this.queue = queue;
    }

    public void clear() {
        neuronQueue.clear();
        timeQueue.clear();
    }

    public double[] popSpikeTimes() {
        double[] data = new double[timeQueue.size()];
        for (int i = 0; i < data.length; i++) {
            data[i] = timeQueue.read();
        }
        return data;
    }

    public Neuron[] popSpikeNeurons() {
        Neuron[] data = new Neuron[neuronQueue.size()];
        for (int i = 0; i < data.length; i++) {
            data[i] = neuronQueue.read();
        }
        return data;
    }

    public int nSpike() {   //总共记录了多少个脉冲
        return neuronQueue.size();
    }

    @Override
    public void add(Neuron sorter) {
        //System.out.println("spike add");
        queue.add(sorter);
    }

    @Override
    public Neuron peak() {
        return queue.peak();
    }

    @Override
    public Neuron pop() {
        Neuron data = queue.pop();
        if (data != null) {
//            System.out.println("pop");
            neuronQueue.write(data);
            timeQueue.write(data.sortKey());
        }
        return data;
    }

    @Override
    public int length() {
        return queue.length();
    }
}
