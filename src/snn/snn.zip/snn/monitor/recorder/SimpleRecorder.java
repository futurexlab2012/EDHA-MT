package com.example.futurexlab.edhamt.snn.monitor.recorder;

import java.util.Arrays;

/**
 * 最简单的记录器，根据写入的数据生成字节流
 */
public class SimpleRecorder {
    private byte[] buffer;
    private int writePtr = 0; //写指针

    private void grow() {
        byte[] newBuffer = new byte[buffer.length * 2];
        for (int i = 0; i < writePtr; i++) {
            newBuffer[i] = buffer[i];
        }
        buffer = newBuffer;
    }

    private void writeBuffer(byte[] data) {
        if (writePtr + data.length > buffer.length) {
            grow();
        }
        for (byte datum : data) {
            buffer[writePtr] = datum;
            writePtr++;   //先写后移动
        }
    }

    public void writeInt(int data) {
        byte[] temp = new byte[4];
        for (int i = 0; i < 4; i++) {
            temp[i] = (byte) (data & 0xff);
            data = data >> 8;//右移一个字节
        }
        writeBuffer(temp);
    }

    public void writeFloat(float data) {
        byte[] temp = new byte[4];
        int fbit = Float.floatToIntBits(data);
        for (int i = 0; i < 4; i++) {
            temp[i] = (byte) (fbit & 0xff);
            fbit = fbit >> 8;//右移一个字节
        }
        writeBuffer(temp);
    }

    public void writeDouble(double data) {
        byte[] temp = new byte[8];
        long dbit = Double.doubleToRawLongBits(data);
        for (int i = 0; i < 8; i++) {     //double有8个字节
            temp[i] = (byte) (dbit & 0xff);
            dbit = dbit >> 8;//右移一个字节
        }
        writeBuffer(temp);
    }

    public byte[] getData() {
        return Arrays.copyOf(buffer, writePtr);
    }

    public void clear() {
        writePtr = 0;
    }

    public SimpleRecorder(int n) {
        buffer = new byte[n];
    }
}
