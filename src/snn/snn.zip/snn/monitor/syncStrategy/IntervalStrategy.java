package com.example.futurexlab.edhamt.snn.monitor.syncStrategy;

/**
 * 简单的按照固定间隔进行同步的策略
 * UT:pass
 */
public class IntervalStrategy implements SyncStrategy {
    private final int n;
    private int count = 0;

    public IntervalStrategy(int n) {
        this.n = n;
    }

    @Override
    public boolean ok(double currentTime) {
        count++;
        if (count % n == 0) {
            count = 0;
            return true;
        }
        return false;
    }
}
