package com.example.futurexlab.edhamt.snn.monitor.syncStrategy;

/**
 * 同步策略
 */
public interface SyncStrategy {
    /**
     * @param currentTime 当前时间
     * @return 是否可以进行更新
     */
    boolean ok(double currentTime);
}
