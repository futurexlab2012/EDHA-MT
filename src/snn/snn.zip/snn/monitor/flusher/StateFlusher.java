package com.example.futurexlab.edhamt.snn.monitor.flusher;

import java.lang.reflect.Field;
import java.util.*;


public final class StateFlusher implements Flusher {
    private final HashMap<Object, HashMap<Field, Integer>> preOffsetMap = new HashMap<>();
    private final HashMap<Object, HashMap<Field, Integer>> postOffsetMap = new HashMap<>();
    private byte[] buffer;
    private final ArrayList<RegisterBucket> orders = new ArrayList<>();

    private final HashSet<RegisterBucket> set = new HashSet<>();

    static public final int PRE_REGISTER_TYPE = 0x01;
    static public final int POST_REGISTER_TYPE = 0x02;
    static public final int ALL_REGISTER_TYPE = PRE_REGISTER_TYPE | POST_REGISTER_TYPE;

    private static class RegisterBucket {
        Object obj;
        Field field;
        int registerType;

        public RegisterBucket(Object obj, Field field, int registerType) {
            this.obj = obj;
            this.field = field;
            this.registerType = registerType;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            RegisterBucket that = (RegisterBucket) o;
            return Objects.equals(obj, that.obj) &&
                    Objects.equals(field, that.field);
        }

        @Override
        public int hashCode() {   //重写hash方法，且只比较obj和field，用于查重
            return Objects.hash(obj, field);
        }
    }



    public void register(Object target, Field arg, int registerType) throws Exception {
        checkType(arg);
        if (!set.add(new RegisterBucket(target, arg, registerType))) {        //不能重复记录
            throw new Exception("target and arg is existed");
        }
        orders.add(new RegisterBucket(target, arg, registerType));   //记录顺序
    }


    private void checkType(Field arg) throws Exception {

        if (arg.getType() != int.class && arg.getType() != double.class && arg.getType() != float.class) {
            throw new Exception("only support int,double and double " + arg.getType().toString());
        }
    }



    public String start() {
        StringBuilder builder = new StringBuilder("<");
        int offset = 0;
        for (RegisterBucket order : orders) {
            Object obj = order.obj;
            Field arg = order.field;
            int registerType = order.registerType;
            if (registerType != 0) {
                if (arg.getType() == double.class) {
                    builder.append("d");
                } else if (arg.getType() == float.class) {
                    builder.append("f");
                } else if (arg.getType() == int.class) {
                    builder.append("i");
                }
            }
            int offsetPre = 0;
            int offsetPost = 0;
            if ((registerType & 0x01) != 0) {
                offsetPre = putOffset(offset, obj, arg, preOffsetMap);
            }
            if ((registerType & 0x02) != 0) {
                offsetPost = putOffset(offset, obj, arg, postOffsetMap);
            }
            offset = Math.max(Math.max(offsetPost, offsetPre), offset);
        }
        buffer = new byte[offset];
        set.clear();
        orders.clear();
        return builder.toString();
    }

    private int putOffset(int offset, Object obj, Field arg, HashMap<Object, HashMap<Field, Integer>> postOffsetMap) {
        HashMap<Field, Integer> objectArgs = postOffsetMap.computeIfAbsent(obj, k -> new HashMap<>());
        if (arg.getType() == float.class || arg.getType() == int.class) {
            objectArgs.put(arg, offset);
            offset += 4;
        } else if (arg.getType() == double.class) {
            objectArgs.put(arg, offset);
            offset += 8;
        }
        return offset;
    }

    private void writeBuffer(int data, int offset) {
        for (int i = 0; i < 4; i++) {
            buffer[offset + i] = (byte) (data & 0xff);
            data = data >> 8;
        }
    }

    private void writeBuffer(float data, int offset) {
        int fbit = Float.floatToIntBits(data);
        for (int i = 0; i < 4; i++) {
            buffer[offset + i] = (byte) (fbit & 0xff);
            fbit = fbit >> 8;
        }
    }

    private void writeBuffer(double data, int offset) {
        long dbit = Double.doubleToRawLongBits(data);
        for (int i = 0; i < 8; i++) {
            buffer[offset + i] = (byte) (dbit & 0xff);
            dbit = dbit >> 8;
        }
    }

    private void writeField(Field arg, Object target, int offset) {
        arg.setAccessible(true);
        if (arg.getType() == int.class) {
            try {
                writeBuffer(arg.getInt(target), offset);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        } else if (arg.getType() == float.class) {
            try {
                writeBuffer(arg.getFloat(target), offset);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        } else if (arg.getType() == double.class) {
            try {
                writeBuffer(arg.getDouble(target), offset);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
    }

    private void writeObject(Object target, HashMap<Object, HashMap<Field, Integer>> preOffsetMap) {
        if (!preOffsetMap.containsKey(target)) {
            return;
        }
        HashMap<Field, Integer> objectArgs = preOffsetMap.get(target);
        for (Map.Entry<Field, Integer> fieldIntegerEntry : objectArgs.entrySet()) {
            Field arg = fieldIntegerEntry.getKey();
            int offset = fieldIntegerEntry.getValue();
            writeField(arg, target, offset);
        }
    }

    @Override
    public void flushPreSpikeObject(Object target) {
        writeObject(target, preOffsetMap);
    }

    @Override
    public void flushPostSpikeObject(Object target) {
        writeObject(target, postOffsetMap);
    }

    @Override
    public byte[] getData() {
        return buffer;
    }
}
