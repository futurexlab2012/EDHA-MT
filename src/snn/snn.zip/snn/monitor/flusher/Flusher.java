package com.example.futurexlab.edhamt.snn.monitor.flusher;


public interface Flusher {

    void flushPreSpikeObject(Object obj);


    void flushPostSpikeObject(Object obj);


    public byte[] getData();
}
