package com.example.futurexlab.edhamt.snn.monitor.dataChannel;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class FileChannel implements DataChannel{
    @Override
    public void send(byte[] data) {

    }

    @Override
    public void send(byte[] data, String name) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(name);
            fileOutputStream.write(data);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
