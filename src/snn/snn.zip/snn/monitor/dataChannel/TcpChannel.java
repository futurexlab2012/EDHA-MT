package com.example.futurexlab.edhamt.snn.monitor.dataChannel;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;


public class TcpChannel implements DataChannel {

    OutputStream stream;

    public TcpChannel(String ip, int port, String messageChanID) {
        Socket s = null;
        try {
            s = new Socket(ip, port);
            stream = s.getOutputStream();
            stream.write(messageChanID.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void send(byte[] data) {
        try {
//            for (byte datum : data) {
//                System.out.println(datum);
//            }
            stream.write(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void send(byte[] data, String name) {
        send(data);
    }
}
