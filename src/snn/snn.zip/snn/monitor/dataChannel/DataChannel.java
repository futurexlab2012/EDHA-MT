package com.example.futurexlab.edhamt.snn.monitor.dataChannel;

/**
 * Used to send messages out
 */

public interface DataChannel {
    /**
     *
     * @param data Data to be sent
     */
    void send(byte[] data);
    void send(byte[] data,String name);
}
