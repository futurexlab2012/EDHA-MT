package com.example.futurexlab.edhamt.snn.monitor.loader;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;


public class SimpleLoader {
    private InputStream inputStream;

    public SimpleLoader(String fileName) {
        try {
            inputStream = new FileInputStream(fileName);
        } catch (FileNotFoundException e) {
            System.exit(1);
            e.printStackTrace();
        }
    }

    public Integer readInt() {
        byte[] cache = new byte[4];
        try {
            int n = inputStream.read(cache, 0, 4);
            if (n < 4) {
                return null;
            }
            int data = 0;
            data |= (cache[0] & 0xff);
            data |= (cache[1] & 0xff) << 8;
            data |= (cache[2] & 0xff) << 16;
            data |= (cache[3] & 0xff) << 24;
            return data;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Float readFloat() {
        byte[] cache = new byte[4];
        try {
            int n = inputStream.read(cache, 0, 4);
            if (n < 4) {
                return null;
            }
            int data = 0;
            data |= (cache[0] & 0xff);
            data |= (cache[1] & 0xff) << 8;
            data |= (cache[2] & 0xff) << 16;
            data |= (cache[3] & 0xff) << 24;
            return Float.intBitsToFloat(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Double readDouble() {
        byte[] cache = new byte[8];
        try {
            int n = inputStream.read(cache, 0, 8);
            if (n < 8) {
                return null;
            }
            long tempdouble = 0;
            tempdouble |= (long) (cache[0] & 0xff);
            tempdouble |= (long) (cache[1] & 0xff) << 8;
            tempdouble |= (long) (cache[2] & 0xff) << 16;
            tempdouble |= (long) (cache[3] & 0xff) << 25;
            tempdouble |= (long) (cache[4] & 0xff) << 32;
            tempdouble |= (long) (cache[5] & 0xff) << 40;
            tempdouble |= (long) (cache[6] & 0xff) << 48;
            tempdouble |= (long) (cache[7] & 0xff) << 56;
            return Double.longBitsToDouble(tempdouble);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
