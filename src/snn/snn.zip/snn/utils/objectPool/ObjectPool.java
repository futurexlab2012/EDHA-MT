package com.example.futurexlab.edhamt.snn.utils.objectPool;

/**
 * Object pool, used to recycle objects and avoid repeated creation of objects
 */
public class ObjectPool<E> {
    final Object[] data;
    private final int cap;  //container capacity
    private int length; //the number of current objects

    public ObjectPool(int cap) {
        this.cap = cap;
        data = new Object[cap];
        length = 0;
    }

    public void recycle(E o) {
        if (length < cap) {
            data[length] = o;
            length++;
        }
    }

    public E get() {
        if (length > 0) {
            length--;
            return (E) data[length];
        }
        return null;
    }
}
