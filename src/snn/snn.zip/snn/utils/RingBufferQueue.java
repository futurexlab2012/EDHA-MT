package com.example.futurexlab.edhamt.snn.utils;

/**
 * Ring buffer queue, which can be automatically expanded
 */
public class RingBufferQueue<T> {
    Object[] buffer;
    private int writePtr = 0;
    private int readPtr = 0;
    private int size = 0;   //current readable capacity

    public RingBufferQueue(int cap) {
        buffer = new Object[cap];
    }

    private void grow() {
        Object[] newBuffer = new Object[buffer.length * 2];
        int newWritePtr = 0;
        while (size > 0) {
            newBuffer[newWritePtr] = readBuffer();
            newWritePtr++;
        }
        this.buffer = newBuffer;
        this.writePtr = newWritePtr;
        this.readPtr = 0;
        this.size = newWritePtr;
//        System.out.println("buffer grow");
    }

    private void writeBuffer(T data) {
        if (size >= buffer.length) {
            grow();
        }
        buffer[writePtr] = data;    //write first and move later
        writePtr = (writePtr + 1) % buffer.length;
        size++;

    }

    private T readBuffer() {
        if (size <= 0) {
            return null;
        } else {
            Object data = buffer[readPtr];   //read first and move later
            readPtr = (readPtr + 1) % buffer.length;
            size--;
            return (T) data;
        }
    }

    public void clear() {
        writePtr = 0;
        readPtr = 0;
        size = 0;
    }

    public int size() {
        return size;
    }

    public T peak() {
        if (size <= 0) {
            return null;
        }
        return (T) buffer[readPtr];
    }

    public void write(T data) {
        writeBuffer(data);
    }

    public T read() {
        return readBuffer();
    }
}
