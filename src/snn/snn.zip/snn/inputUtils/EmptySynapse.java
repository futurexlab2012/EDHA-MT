package com.example.futurexlab.edhamt.snn.inputUtils;

import com.example.futurexlab.edhamt.snn.neuron.components.synapse.Synapse;

/**
 * It doesn't do any concrete work, just passing messages.
 */

public class EmptySynapse implements Synapse {
    @Override
    public double preSpike(double currentTime) {
        return 0;
    }

    @Override
    public void postSpike(double currentTime) {

    }
}
