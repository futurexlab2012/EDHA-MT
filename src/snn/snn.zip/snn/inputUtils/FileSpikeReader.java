package com.example.futurexlab.edhamt.snn.inputUtils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

/**
 * SpikeReader based on IO
 */
public class FileSpikeReader implements SpikeReader {

    private InputStream reader;

    public FileSpikeReader(String filePath) throws FileNotFoundException {
        reader = new FileInputStream(filePath);
    }

    @Override
    public SpikePack read() {
        byte[] cache = new byte[12];
        int n = 0;   //index+spikeTime
        try {
            n = reader.read(cache, 0, 12);
        } catch (IOException ioException) {
            return null;
        }
        if (n != 12) {
            return null;
        }
        int index = 0;
        index |= (cache[0] & 0xff) << 24;
        index |= (cache[1] & 0xff) << 16;
        index |= (cache[2] & 0xff) << 8;
        index |= (cache[3] & 0xff);

        long tempdouble = 0;
        tempdouble |= (long) (cache[4] & 0xff) << 56;
        tempdouble |= (long) (cache[5] & 0xff) << 48;
        tempdouble |= (long) (cache[6] & 0xff) << 40;
        tempdouble |= (long) (cache[7] & 0xff) << 32;
        tempdouble |= (long) (cache[8] & 0xff) << 24;
        tempdouble |= (long) (cache[9] & 0xff) << 16;
        tempdouble |= (long) (cache[10] & 0xff) << 8;
        tempdouble |= (long) (cache[11] & 0xff);
        double spikeTime = Double.longBitsToDouble(tempdouble);
        return new SpikePack(index, spikeTime);
    }

    public void close(){
        try {
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
