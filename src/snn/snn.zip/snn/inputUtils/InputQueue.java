package com.example.futurexlab.edhamt.snn.inputUtils;

import com.example.futurexlab.edhamt.snn.neuron.Neuron;
import com.example.futurexlab.edhamt.snn.queue.ReentrantQueue;
import com.example.futurexlab.edhamt.snn.utils.RingBufferQueue;

/**
 * Store only the queue of input neurons spikes
 */

public class InputQueue implements ReentrantQueue<Neuron> {

    private final Neuron[] inputNeurons;
    private RingBufferQueue<SpikePack> bufferQueue = new RingBufferQueue<>(64);
    private double lastSpike = 0;


    public InputQueue(Neuron[] inputNeurons) {
        this.inputNeurons = inputNeurons;
    }

    @Override
    public void add(Neuron sorter) {
    }

    /**
     * Add an input neuron spike
     */
    public void addSpike(SpikePack spikePack) {
        if (spikePack.spikeTime < lastSpike) {
            new Exception("current spike is less than previous spike, current="+spikePack.spikeTime+", previous="+lastSpike).printStackTrace();
            System.exit(1);
        }
        lastSpike = spikePack.spikeTime;
        bufferQueue.write(spikePack);
    }

    @Override
    public Neuron peak() {
        SpikePack pack = bufferQueue.peak();
        if (pack != null) {
            Neuron neuron = inputNeurons[pack.index];
            neuron.setExpectSpikeTime(pack.spikeTime);
            return neuron;
        }
        return null;
    }

    @Override
    public Neuron pop() {
        SpikePack pack = bufferQueue.read();
        if (pack != null) {
            Neuron neuron = inputNeurons[pack.index];
            neuron.setExpectSpikeTime(pack.spikeTime);
            return neuron;
        }
        return null;
    }

    @Override
    public int length() {
        return bufferQueue.size();
    }
}
