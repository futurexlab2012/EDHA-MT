package com.example.futurexlab.edhamt.snn.inputUtils;

import com.example.futurexlab.edhamt.snn.neuron.components.soma.Soma;

/**
 * Spikes input cell body, with OriginSoma to achieve spike signal input, need to cooperate with self-connection to achieve spike management.
 */

public class InputSoma implements Soma {

    private double[] buffer;
    private int bufferCap;
    private int writePtr = 0;
    private int readPtr = 0;
    private int size = 0;

    /**
     * @param bufferCap
     * The initial capacity of the ring buffer array
     * The capacity will be dynamically expanded if the capacity is insufficient.
     * Therefore, you are not advised to set the size to too large.
     */
    public InputSoma(int bufferCap) {
        buffer = new double[bufferCap];
        this.bufferCap = bufferCap;
    }

    /**
     * Increases dynamically when the buffer capacity is insufficient.
     */
    private void grow() {
        double[] newBuffer = new double[bufferCap * 2];
        bufferCap = bufferCap * 2;
        int newWritePtr = 0;
        while (size > 0) {
            newBuffer[newWritePtr] = readBuffer();
            newWritePtr++;
        }
        this.buffer = newBuffer;
        this.writePtr = newWritePtr;
        this.readPtr = 0;
        this.size = newWritePtr;
        System.out.println("buffer grow");
    }

    private void writeBuffer(double data) {
        if (size >= bufferCap) {
            grow();
        }
        buffer[writePtr] = data;
        writePtr = (writePtr + 1) % bufferCap;
        size++;

    }

    private double readBuffer() {
        if (size <= 0) {
            return -1;
        } else {
            double data = buffer[readPtr];
            readPtr = (readPtr + 1) % bufferCap;
            size--;
            return data;
        }
    }

    /**
     * Add spikes for current neuron
     *
     * @param spikeTime spike time of neuron
     */
    public void addSpike(double spikeTime) {
        writeBuffer(spikeTime);
    }

    @Override
    public double update(double deltaGe, double currentTime) {
        double data = readBuffer();
        return data > 0 ? data : -1;
        //Returns the next spike in the queue, or -1 if there is no pulse, mainly to reduce coupling.
    }
}
