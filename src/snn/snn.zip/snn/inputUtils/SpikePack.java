package com.example.futurexlab.edhamt.snn.inputUtils;


public class SpikePack {

    public int index;
    public double spikeTime;

    public SpikePack(int index, double spikeTime) {
        this.index = index;
        this.spikeTime = spikeTime;
    }
}
