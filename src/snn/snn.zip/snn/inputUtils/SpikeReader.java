package com.example.futurexlab.edhamt.snn.inputUtils;

/**
 * Obtain spikes
 */

public interface SpikeReader {
    /**
     * @return return spikes, if not spikes, return null
     */
    SpikePack read();
}
