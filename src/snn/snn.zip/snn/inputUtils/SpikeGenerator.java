package com.example.futurexlab.edhamt.snn.inputUtils;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Generate spike file. Note, this class does not have sorting function, please user implementation.
 * UT：pass
 */

public class SpikeGenerator {

    private final OutputStream stream;
    private double lastAddedTime = -1;

    public SpikeGenerator(OutputStream stream) {
        this.stream = stream;
    }

    /**
     * Add spikes, which are recorded using subscripts, independent of specific neurons, and need to complete the mapping work by themselves.
     * Note that only simple spike addition function is provided here, no sorting process is carried out, and disordered spike time will lead to calculation errors.
     * Need to complete spike time sequencing
     *
     * @param index     subscript of neuron
     * @param spikeTime spike time
     *                  Numerical please make sure that the incoming is double, because the Java type conversion by default,
     *                  the incoming low precision type (float, int) won't be an error,
     *                  but as a result of or beyond the range accuracy limit overflow problem caused by wrong data,
     *                  such as more than 596 * 3600 * 1000 int variables will overflow,
     *                  The float type is too high and fails due to insufficient precision. Please note ！！！！！！！
     */
    public void addSpike(int index, double spikeTime) {
        if (spikeTime < lastAddedTime) {
            new Exception("error order").printStackTrace();
        }
        lastAddedTime = spikeTime;
        byte[] buffer = new byte[12];
        for (int i = 3; i >= 0; i--) {
            buffer[i] = (byte) (index & 0xff);
            index = index >> 8;
        }
        long tempSpike = Double.doubleToLongBits(spikeTime);
        for (int i = 7; i >= 0; i--) {
            buffer[4 + i] = (byte) (tempSpike & 0xff);
            tempSpike = tempSpike >> 8;
        }
        try {
            stream.write(buffer, 0, 12);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void flush() {
        try {
            stream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void close() {
        try {
            stream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
