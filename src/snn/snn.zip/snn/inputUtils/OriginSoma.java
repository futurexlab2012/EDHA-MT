package com.example.futurexlab.edhamt.snn.inputUtils;

import com.example.futurexlab.edhamt.snn.neuron.components.soma.Soma;

/**
 * The origin of all neurons for the input of spikes
 * coincidence
 */

public class OriginSoma implements Soma {

    private final InputSoma[] inputSomas;  //All neuron soma
    private final SpikeReader spikeReader;
    private final int n;
    private SpikePack nextPack;

    /**
     * @param inputSomas  input neuron soma
     * @param spikeReader source of spikes
     * @param n           the number of spikes read each time
     */
    public OriginSoma(InputSoma[] inputSomas, SpikeReader spikeReader, int n) {
        this.inputSomas = inputSomas;
        this.spikeReader = spikeReader;
        this.n = n;
        nextPack = spikeReader.read();
    }

    /**
     * @param deltaGe     change in ge
     * @param currentTime current time
     * @return  Return the middle value of the last spike that has been processed and the first spike that has not been processed.
     * If the interval between these two spikes is small, it needs to be removed to avoid interference caused by "double" accuracy.
     */
    @Override
    public double update(double deltaGe, double currentTime) {
        System.out.println("origin "+nextPack);
        SpikePack spikePack = null;
        if (nextPack == null) {
            return -1;
        }
        inputSomas[nextPack.index].addSpike(nextPack.spikeTime);  //Outgoing this time is the last spike that was read in but not outgoing.
        for (int i = 0; i < n - 1; i++) {
            spikePack = spikeReader.read();
            if (spikePack == null) {
                return -1;   //There are no more spikes. The current Origin mission is over
            }
            inputSomas[spikePack.index].addSpike(spikePack.spikeTime);
        }
        nextPack = spikeReader.read();   //The next spike, not this time outgoing
        return nextPack == null ? -1 : (spikePack.spikeTime + nextPack.spikeTime) / 2;   // Outgoing the same time as the last spike
        // Because the remaining spikes are cached in InputSoma, there is no problem of spike loss.
    }
}
