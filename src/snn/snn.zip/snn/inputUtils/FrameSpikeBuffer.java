package com.example.futurexlab.edhamt.snn.inputUtils;

/**
 * A spike buffer
 * Read per frame
 */

public class FrameSpikeBuffer implements SpikeReader {
    private SpikePack[] buffer;
    private int bufferCap;
    private int writePtr = 0; //Write pointer
    private int readPtr = 0; //Read pointer
    private int size = 0;   //Current readable capacity

    private void grow() {
        SpikePack[] newBuffer = new SpikePack[bufferCap * 2];
        bufferCap = bufferCap * 2;
        int newWritePtr = 0;
        while (size > 0) {
            newBuffer[newWritePtr] = readBuffer();
            newWritePtr++;
        }
        this.buffer = newBuffer;
        this.writePtr = newWritePtr;
        this.readPtr = 0;
        this.size = newWritePtr;
        System.out.println("buffer grow");
    }

    private void writeBuffer(SpikePack data) {
        if (size >= bufferCap) {
            grow();
        }
        buffer[writePtr] = data;    //Write first and move later
        writePtr = (writePtr + 1) % bufferCap;
        size++;

    }

    private SpikePack readBuffer() {
        if (size <= 0) {
            return null;
        } else {
            SpikePack data = buffer[readPtr];   //Read first and move later
            readPtr = (readPtr + 1) % bufferCap;
            size--;
            return data;
        }
    }

    public FrameSpikeBuffer(int n) {
        buffer = new SpikePack[n];
        bufferCap = n;
    }

    @Override
    public SpikePack read() {
        return readBuffer();
    }

    public void write(SpikePack data, double offset) {
        writeBuffer(new SpikePack(data.index, data.spikeTime + offset));
    }
}
