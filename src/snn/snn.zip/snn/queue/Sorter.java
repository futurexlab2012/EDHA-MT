package com.example.futurexlab.edhamt.snn.queue;


public interface Sorter {
    double sortKey();
}