package com.example.futurexlab.edhamt.snn.queue;


public interface RepeatableSorter extends Sorter {
    boolean repeatable();
}
