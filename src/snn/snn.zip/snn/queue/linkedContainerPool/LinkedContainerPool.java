package com.example.futurexlab.edhamt.snn.queue.linkedContainerPool;


public class LinkedContainerPool<T> {
    final LinkedContainer<T> head;
    LinkedContainer<T> tail = null;
    final int cap;
    int length;

    public LinkedContainerPool(int cap) {
        head = new LinkedContainer<>();
        tail = head;
        this.cap = cap;   //set max capacity
    }

    public LinkedContainer<T> get() {
        if (head == tail) {   //remaining elements are empty
            return new LinkedContainer<>();  //return the newly created element
        } else {                             //Otherwise return the cached element
            LinkedContainer<T> container = tail;
            tail = tail.pre;
            container.next = null;
            container.pre = null;
            container.data = null;
            length--;
            return container;
        }
    }

    public void recycle(LinkedContainer<T> container) {
        if (length < cap) {
            container.pre = tail;
            container.next = null;
            container.data = null;
            container.father = null;
            container.inQueue = false;
            tail.next = container;
            tail = container;
            length++;
        }
    }

    public int length() {
        return length;
    }
}
