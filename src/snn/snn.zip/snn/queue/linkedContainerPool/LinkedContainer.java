package com.example.futurexlab.edhamt.snn.queue.linkedContainerPool;


public class LinkedContainer<T> {
    public LinkedContainer<T> pre = null;
    public LinkedContainer<T> next = null;
    public LinkedContainer<T> father = null;
    public T data = null;
    public boolean inQueue = false;

    public LinkedContainer(T data) {
        this.data = data;
    }

    public LinkedContainer() {
//        System.out.println("create");
    }

}
