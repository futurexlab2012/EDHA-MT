package com.example.futurexlab.edhamt.snn.queue;


public class ComboQueue<T extends Sorter> implements ReentrantQueue<T> {

    private final ReentrantQueue<T>[] queues;
    private final ReentrantQueue updatableQueue;

    public ComboQueue(ReentrantQueue<T> updatableQueue, ReentrantQueue<T>... queues) {
        this.queues = new ReentrantQueue[queues.length + 1];
        for (int i = 0; i < queues.length; i++) {
            this.queues[i] = queues[i];
        }
        this.queues[this.queues.length - 1] = updatableQueue;
        this.updatableQueue = updatableQueue;
    }

    @Override
    public void add(T sorter) {
        this.updatableQueue.add(sorter);
//        if (sorter.sortKey()>0) {
//            System.out.println("combo add spike with "+sorter.sortKey());
//        }

    }

    @Override
    public T peak() {
        double minTime = Double.MAX_VALUE;
        T minNeuron = null;
        for (ReentrantQueue<T> queue : queues) {
            T neuron = queue.peak();
            if (neuron != null) {
                if (minTime > neuron.sortKey()) {
                    minTime = neuron.sortKey();
                    minNeuron = neuron;
                }
            }
        }
        return minNeuron;
    }

    @Override
    public T pop() {
        double minTime = Double.MAX_VALUE;
        ReentrantQueue<T> minQueue = null;
        for (ReentrantQueue<T> queue : queues) {
            T neuron = queue.peak();
            if (neuron != null) {
                if (minTime > neuron.sortKey()) {
                    minTime = neuron.sortKey();
                    minQueue = queue;
                }
            }
        }
        return minQueue == null ? null : minQueue.pop();     //The required data should be ejected
    }

    @Override
    public int length() {
        int length = 0;
        for (ReentrantQueue<T> queue : queues) {
            length += queue.length();
        }
        return length;
    }
}
