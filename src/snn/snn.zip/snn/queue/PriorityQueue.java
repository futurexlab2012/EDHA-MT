package com.example.futurexlab.edhamt.snn.queue;

import com.example.futurexlab.edhamt.snn.queue.linkedContainerPool.LinkedContainer;
import com.example.futurexlab.edhamt.snn.queue.linkedContainerPool.LinkedContainerPool;

import java.util.HashMap;

/**
 * the simplest implement, Go back to front, insert
 *
 * @param <T> element type
 */

public class PriorityQueue<T extends Sorter> implements ReentrantQueue<T> {

    private final LinkedContainer<T> head;
    private final LinkedContainer<T> tail;
    private final HashMap<T, LinkedContainer<T>> keyMap = new HashMap<>();
    private final LinkedContainerPool<T> pool;   //recycling pool
    private int length;


    /**
     * @param cap        the maximum capacity of the container cache
     * @param headSorter The front node, equivalently lower limit
     * @param tailSorter The last node, equivalently upper limit
     */
    public PriorityQueue(int cap, T headSorter, T tailSorter) {
        pool = new LinkedContainerPool<>(cap);
        head = pool.get();
        head.data = headSorter;
        tail = pool.get();
        tail.data = tailSorter;
        head.next = tail;
        tail.pre = head;
        tail.next = null;
        length = 0;
    }

    /**
     * Inserts objects into the queue, and updates the target location if the target is already in the queue, similar to the "update" method
     *
     * @param sorter object to be inserted
     */
    @Override
    public void add(T sorter) {
        if (keyMap.containsKey(sorter)) { //if in the queue
            LinkedContainer<T> container = keyMap.get(sorter);
            LinkedContainer<T> next = container.next;
            remove(container);
            if (sorter.sortKey() > 0) {    //If the sorter object meets the criteria for being queued
                if (container.data.sortKey() < next.data.sortKey()) {  //search forward or backward depending on the size
                    forwardInsert(container, next);
                } else {
                    backwardInsert(container, next);
                }
            } else {
                keyMap.remove(sorter);//existing objects can no longer be placed in it, removed it
                pool.recycle(container);  //recycling container
                length--;
            }
        } else if (sorter.sortKey() > 0) {   //Do nothing, if not in the queue and do not meet the queue condition.
            LinkedContainer<T> container = pool.get();
            container.data = sorter;
            forwardInsert(container, tail);           //If the current element is not in the queue, search from end to front
            keyMap.put(sorter, container);
            length++;
        }
    }

    /**
     * Remove the element from the LinkedList
     *
     * @param container element to be remove
     */
    private void remove(LinkedContainer<T> container) {
        container.pre.next = container.next;
        container.next.pre = container.pre;

    }

    /**
     * Start the search from the origin location and insert target into the appropriate location
     *
     * @param target Target node to be inserted
     * @param origin The initial node to search forward
     */
    public void forwardInsert(LinkedContainer<T> target, LinkedContainer<T> origin) {
        double targetSortKey = target.data.sortKey();
        while (origin.pre.data.sortKey() > targetSortKey) {
//            System.out.println(origin.data.sortKey());
            origin = origin.pre;
        }
        target.next = origin;
        target.pre = origin.pre;
        origin.pre.next = target;
        origin.pre = target;
    }

    public void backwardInsert(LinkedContainer<T> target, LinkedContainer<T> origin) {
        double targetSortKey = target.data.sortKey();
        while (origin.data.sortKey() < targetSortKey) {
            origin = origin.next;
        }
        target.next = origin;
        target.pre = origin.pre;
        origin.pre.next = target;
        origin.pre = target;
    }


    @Override
    public T peak() {
        return head.next.data;
    }

    @Override
    public T pop() {
        if (head.next == tail) {
            return tail.data;
        }
        LinkedContainer<T> container = head.next;
        T data = container.data;
        remove(container);                       //Removes containers from the LinkedList
        keyMap.remove(container.data);           //Remove elements from the map
        pool.recycle(container);
        length--;
        return data;
    }

    public int length() {
        return length;
    }
}
