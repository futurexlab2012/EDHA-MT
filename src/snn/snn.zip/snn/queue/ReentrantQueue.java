package com.example.futurexlab.edhamt.snn.queue;


public interface ReentrantQueue<T extends Sorter> {
    /**
     * Add elements to the container
     *
     * @param sorter data to be added
     */
    void add(T sorter);

    /**
     * View the top data without removing it
     *
     * @return top data, returns null if the top data is null
     */
    T peak();

    /**
     * Gets the top element of the queue and removes it
     *
     * @return top data, returns null if the top data is null
     */
    T pop();

    int length();
}
