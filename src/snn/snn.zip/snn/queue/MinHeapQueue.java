package com.example.futurexlab.edhamt.snn.queue;

import com.example.futurexlab.edhamt.snn.utils.objectPool.ObjectPool;

import java.util.HashMap;


/**
 * Priority queue based on small root heap implementation
 * The main difference between MinHeapQueue and MinHeapQueue is that it does not support repeatable elements and optimizes redundant parts
 *
 * @param <T> container type
 */

public class MinHeapQueue<T extends Sorter> implements ReentrantQueue<T> {
    static public class Container<E> {
        E data;
        double key;
        int index;
    }

    private Container<T>[] array = new Container[16];  //to store data
    private HashMap<T, Container<T>> keyMap = new HashMap<>();   //sorter mapping to a specific location
    private ObjectPool<Container<T>> pool = new ObjectPool<>(256);
    private int length = 0;
    private int maxLength = 0;


    private void recycle(Container<T> e) {
        pool.recycle(e);
    }

    private Container<T> getContainer() {
        Container<T> e = pool.get();
        return e == null ? new Container<T>() : e;   //object pool empty new, otherwise return the container in the object pool
    }

    /**
     * Restores the sequence from the current node up
     *
     * @param i index of the current node
     */
    private int arrangeUp(int i, Container<T>[] array, int length) {
        if (i <= 0) {
            return 0;
        }
        if (array[i].key < array[father(i)].key) {
            swapArrayData(array, i, father(i));  //swap the current node and the parent node
            return arrangeUp(father(i), array, length);
        }
        return i;   //nothing happens, the elements are still in their original positions

    }

    /**
     * Restores the sequence from the current node down
     *
     * @param i index of the current node
     */
    private int arrangeDown(int i, Container<T>[] array, int length) {
        int minIndex = i;
        double minVal = Double.MAX_VALUE;
        if (left(i) < length) {
            minIndex = left(i);
            minVal = array[left(i)].key;
            if (right(i) < length && minVal > array[right(i)].key) {
                minVal = array[right(i)].key;
                minIndex = right(i);
            }
        }
        if (minIndex != i && minVal < array[i].key) {
            swapArrayData(array, i, minIndex);
            return arrangeDown(minIndex, array, length);    //iteration
        }
        return i;  //nothing happens, the elements are still in their original positions
    }

    /**
     * Grows when the array capacity is insufficient
     */
    private void grow() {
        Container<T>[] array = new Container[this.array.length * 2];   //the capacity is doubled
        if (length >= 0) System.arraycopy(this.array, 0, array, 0, length);  //copy the array
        this.array = array;
    }

    private int left(int i) {
        return 2 * i + 1;
    }

    private int right(int i) {
        return 2 * i + 2;
    }

    private int father(int i) {
        return (i - 1) / 2;
    }

    private void setArrayData(Container<T>[] array, int index, Container<T> sorter) {

        array[index] = sorter;
        array[index].index = index;


    }

    private void swapArrayData(Container<T>[] array, int left, int right) {
        Container<T> temp = array[left];
        array[left] = array[right];
        array[right] = temp;
        array[left].index = left;
        array[right].index = right;
    }

    private Container<T> addSafely(T sorter) {
        if (length >= array.length) {// The capacity is automatically expanded when the capacity is insufficient. Currently, there is no automatic reduction mechanism.
            grow();
        }
        Container<T> container = getContainer();
        container.data = sorter;
        container.key = sorter.sortKey();
        setArrayData(array, length, container);   //Add a new element at the end
        arrangeUp(length, array, length + 1);
        length++;
        if (length > maxLength) {
            maxLength = length;
        }
        return container;
    }


    @Override
    public void add(T sorter) {
        Container<T> container = keyMap.get(sorter);
        if (container == null) { //non-repeatable element but does not exist
            if (sorter.sortKey() > 0) {
//                System.out.println(sorter.sortKey() + "  " + length +" "+((Neuron)sorter).getAlias());
                keyMap.put(sorter, addSafely(sorter));
            }
        } else if (sorter.sortKey() <= 0) {      //Non-repeatable, does not meet the conditions for continued existence
            array[container.index].data = null;  //First empty the original container, which is equivalent to deleting the node
            keyMap.remove(sorter);  //Put the data in a new container and put it into a KeyMap
        } else {      //A repeatable element that is eligible to continue to exist, updates its position
            array[container.index].key = sorter.sortKey();  //Update sort key
            arrangeDown(container.index, array, length);   //First down, make sure the index position is the minimum
            arrangeUp(container.index, array, length);  //Then up, make sure the minimum is on top
        }
    }

    /**
     * safely pop
     */
    public void popSafely() {
        if (length == 0) {
            return;             //if empty, it is not popping
        }
        if (array[0].data != null) {              //If there are elements in the container, the container is valid
            keyMap.remove(array[0].data);
        }
        recycle(array[0]);


        setArrayData(array, 0, array[length - 1]);
        arrangeDown(0, array, length - 1);
        length--;

    }

    @Override
    public T peak() {
        if (length == 0) {
            return null;
        } else {
            T ele = array[0].data;
            if (ele == null) {         // If the current container is empty, pop up and use the next one
                popSafely();
                return peak();
            }
            return ele;
        }
    }

    @Override
    public T pop() {
        if (length == 0) {
            return null;          //array is empty
        } else {
            T ele = array[0].data;
            popSafely();               // pop the top element
            if (ele == null) {         // If the current container is empty, recursively called
                return pop();
            }
            return ele;
        }
    }

    @Override
    public int length() {
        return length;
    }

    public int getMaxLength() {
        return maxLength;
    }
}
