package com.example.futurexlab.edhamt.snn;

public enum SNNResult {
    NO_SPIKE_ANY_MORE,
    OVER_TIME
}
